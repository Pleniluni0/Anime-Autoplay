// player.js PRO MAX

(function () {
  'use strict';

  function detect() {
    if (document.querySelector('.jwplayer')) return 'jwplayer';
    if (document.querySelector('.vjs-tech')) return 'videojs';
    if (document.querySelector('video')) return 'html5';
    return 'unknown';
  }

  function playHTML5() {
    const v = document.querySelector('video');
    if (!v) return false;

    v.muted = true;

    return v.play()
      .then(() => {
        setTimeout(() => {
          v.muted = false;
          if (v.volume === 0) v.volume = 1;
        }, 300);
        return true;
      })
      .catch(() => false);
  }

  function playJW() {
    const btn = document.querySelector('.jw-icon-play');
    if (btn) {
      btn.click();
      return true;
    }
    return playHTML5();
  }

  function playVideoJS() {
    const btn = document.querySelector('.vjs-play-control');
    if (btn) {
      btn.click();
      return true;
    }
    return playHTML5();
  }

  function forceInteraction() {
    const el = document.body;
    ['pointerdown','mousedown','mouseup','click'].forEach(type => {
      el.dispatchEvent(new MouseEvent(type, { bubbles: true }));
    });
  }

  function smartPlay() {
    const type = detect();

    forceInteraction();

    switch (type) {
      case 'jwplayer': return playJW();
      case 'videojs': return playVideoJS();
      case 'html5': return playHTML5();
      default: return playHTML5();
    }
  }

  // 🔥 reintento inteligente (CLAVE)
  function retryPlay() {
    let tries = 0;

    const interval = setInterval(() => {
      tries++;

      const success = smartPlay();

      if (success || tries > 15) {
        clearInterval(interval);
      }
    }, 700);
  }

  window.addEventListener('message', (e) => {
    if (!e.data || e.data._aap !== true) return;

    if (e.data.type === 'PLAY') {
      retryPlay();
    }
  });

})();