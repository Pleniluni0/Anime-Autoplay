// bridge.js PRO MAX

(function () {
  'use strict';

  function forwardToChildren(data) {
    document.querySelectorAll('iframe').forEach(f => {
      try { f.contentWindow.postMessage(data, '*'); } catch (_) {}
    });
  }

  function forwardToParent(data) {
    try { window.parent.postMessage(data, '*'); } catch (_) {}
    try { window.top.postMessage(data, '*'); } catch (_) {}
  }

  window.addEventListener('message', (e) => {
    if (!e.data || e.data._aap !== true) return;

    if (e.data.type === 'PLAY') {
      forwardToChildren(e.data);
    }

    if (e.data.type === 'TRIGGER') {
      forwardToParent(e.data);
    }
  });

})();