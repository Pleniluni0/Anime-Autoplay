// main.js PRO MAX

(function () {
  'use strict';

  if (window.self !== window.top) return;

  function sendPlayToAll() {
    document.querySelectorAll('iframe').forEach(f => {
      try {
        f.contentWindow.postMessage({
          _aap: true,
          type: 'PLAY'
        }, '*');
      } catch (_) {}
    });
  }

  // 🔥 autoplay robusto
  function autoplaySystem() {
    let tries = 0;

    const interval = setInterval(() => {
      tries++;

      const video = document.querySelector('video');

      if (video) {
        video.muted = true;

        video.play()
          .then(() => {
            setTimeout(() => {
              video.muted = false;
            }, 300);
          })
          .catch(() => {});
      }

      sendPlayToAll();

      if (tries > 20) clearInterval(interval);
    }, 600);
  }

  // 🔥 PRELOAD siguiente episodio (tipo Netflix)
  function preloadNextEpisode(url) {
    if (!url) return;

    const iframe = document.createElement('iframe');
    iframe.src = url;

    Object.assign(iframe.style, {
      position: 'absolute',
      width: '1px',
      height: '1px',
      opacity: '0',
      pointerEvents: 'none'
    });

    document.body.appendChild(iframe);
  }

  // 🔥 detectar final real del vídeo
  function detectEnd() {
    const video = document.querySelector('video');

    if (!video) return;

    video.addEventListener('ended', () => {
      goNext();
    });
  }

  function getNextUrl() {
    const btn = document.querySelector('a[rel="next"], a:contains("Siguiente")');
    return btn?.href || null;
  }

  function goNext() {
    const next = getNextUrl();
    if (next) window.location.href = next;
  }

  function init() {
    autoplaySystem();
    detectEnd();

    const next = getNextUrl();
    preloadNextEpisode(next);
  }

  window.addEventListener('load', () => {
    setTimeout(init, 1500);
  });

})();